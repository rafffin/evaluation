$(function(){
    mainSliderImg = [
        "./assets/img/background.jpg",
        "./assets/img/background2.jpg",
    ];

    var mainslider = new MySlider($('.main-slider'), mainSliderImg);

    // on ajuste la hauteur du slider en fonction de l'image la moins haute:
    const ajusteSlider = () => {
        let sliderWidth = $('.main-slider').width();
        let sliderHeight = sliderWidth*450/1400;
        $('.main-slider').height(sliderHeight);
    }

    ajusteSlider();

    // on recalcule la hauteur si l'écran change de taille
    $(window).on('resize', function(e){
        ajusteSlider();
    });

    // les dates picker

    var dateFormat = "mm/dd/yy";

    // datepicker permettant de selectionner le début de la periode
    var from = $( "#from" )
    .datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        showAnim: 'fadeIn',
        numberOfMonths: 1,
        showButtonPanel: true
    })
    .on( "change", function() {
        // on configure le datepicker opposé en fonction du choix utilisateur
        to.datepicker( "option", "minDate", getDate( this ) );
    });

    // datepicker permettant de selectionner la fin de la periode
    var to = $( "#to" )
    .datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        showAnim: 'fadeIn',
        numberOfMonths: 1,
        showButtonPanel: true
    })
    .on( "change", function() {
        // on configure le datepicker opposé en fonction du choix utilisateur
        from.datepicker( "option", "maxDate", getDate( this ) );
    });

    function getDate( element ) {
        var date;
        try {
        date = $.datepicker.parseDate( dateFormat, element.value );
        } catch( error ) {
        date = null;
        }

        return date;
    }

    // on permet aux click sur les icones de déclencher 
    // l'ouverture des pickers
    $(".picker-from .triggerIcon").on('click', function(e){
        from.datepicker("show");
    });

    $(".picker-to .triggerIcon").on('click', function(e){
        to.datepicker("show");
    })

    // menu hamburger
    //click sur le bouton hamburger -> toggle
    $('.hamburger').on('click', function(e){
        e.stopPropagation();
        $('.sliding-menu').slideToggle();
        mainslider.stop();
    });


    // cards
    var data = [
        {
            id: 1,
            modele: "peugeot 208",
            specs: "Diesel, 5 portes, GPS, Autoradio, Forfait 1000km (0,5/km supplémentaire)",
            prix: 999,
            agence: "Agence de Paris",
            lien: "#",
            imgSrc: [
                "./assets/img/vehicule1.png",
                "./assets/img/vehicule2.png",
                "./assets/img/vehicule3.png",
                "./assets/img/vehicule4.png",
            ],
        },
        {
            id: 2,
            modele: "ford focus",
            specs: "Diesel, 5 portes, GPS, Autoradio, Forfait 1000km (0,5/km supplémentaire)",
            prix: 999,
            agence: "",
            lien: "#",
            imgSrc: [
                "./assets/img/vehicule1.png",
                "./assets/img/vehicule2.png",
                "./assets/img/vehicule3.png",
                "./assets/img/vehicule4.png",
            ],
        },
        {
            id: 3,
            modele: "Audi A1",
            specs: "Diesel, 5 portes, GPS, Autoradio, Forfait 1000km (0,5/km supplémentaire)",
            prix: 1100,
            agence: "Agence de Paris",
            lien: "#",
            imgSrc: [
                "./assets/img/vehicule1.png",
                "./assets/img/vehicule2.png",
                "./assets/img/vehicule3.png",
                "./assets/img/vehicule4.png",
            ],
        },
        {
            id: 4,
            modele: "Opel Mokka",
            specs: "Diesel, 5 portes, GPS, Autoradio, Forfait 1000km (0,5/km supplémentaire)",
            prix: 1150,
            agence: "Agence de Paris",
            lien: "#",
            imgSrc: [
                "./assets/img/vehicule1.png",
                "./assets/img/vehicule2.png",
                "./assets/img/vehicule3.png",
                "./assets/img/vehicule4.png",
            ],
        },
    ]

    
    // on boucle sur le tableau de données pour creer et inserer
    // les cartes.
    var carousels = [];

    data.forEach(car => {
        $('.card-container').append(`
        <div class="card">
            <div class="card-img sl-${car.id}"></div>
            <div class="card-info">
                <h3>${car.modele}</h3>
                <small>${car.specs}</small>
                <p>${car.prix} € ${car.agence !== "" ? " - " + car.agence : ""}</p>
                <button class="order">Réserver et payer</button>
            </div>
        </div>
        `);
        carousels[car.id] = new MySlider($('.sl-' + car.id), car.imgSrc);
        carousels[car.id].stop();
    });


}); // fin ready